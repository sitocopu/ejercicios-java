package pkgMain;

public class Alquiler implements Comparable<Alquiler>{

	public Alquiler(int idAlquiler, Cliente cliente, Vehiculo vehiculo, int diasAlquiler) {
		super();
		IdAlquiler = idAlquiler;
		this.cliente = cliente;
		this.vehiculo = vehiculo;
		DiasAlquiler = diasAlquiler;
	}
	
	
	//Propiedades
	private int IdAlquiler;
	private Cliente cliente;
	private Vehiculo vehiculo;
	private int DiasAlquiler;
	
	
	//Getters and Setters
	public int getIdAlquiler() {
		return IdAlquiler;
	}
	public void setIdAlquiler(int idAlquiler) {
		IdAlquiler = idAlquiler;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public Vehiculo getVehiculo() {
		return vehiculo;
	}
	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}
	public int getDiasAlquiler() {
		return DiasAlquiler;
	}
	public void setDiasAlquiler(int diasAlquiler) {
		DiasAlquiler = diasAlquiler;
	}
	
	
	public double CalcularCoste() {
		
		double coste;
		
		coste = this.vehiculo.PrecioAlquiler(DiasAlquiler);
		
		return coste;
		
	}
	@Override
	public int compareTo(Alquiler o) {
		// TODO Auto-generated method stub
		
		int comparador;
		
		if (this.IdAlquiler > o.getIdAlquiler()) {
			
			comparador = 1;
			
		}
		else {
			
			comparador = -1;
			
		}
		
		return comparador;
	}
	
	
}
