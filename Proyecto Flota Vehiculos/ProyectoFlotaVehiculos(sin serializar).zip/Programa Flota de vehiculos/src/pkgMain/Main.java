package pkgMain;
import java.util.Scanner;
public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		//*****Variables*****
		//Vectores para el menu
		String[] opciones = new String[11]; 
		String[] respuestas = new String[11];
		String claveMenu;
		boolean claveSalir = true;
		
		//Se declara la empresa
		Empresa empresa = new Empresa();
		
		//Variables para introducir vehiculos
		int id, numPlazas, numKilos, tipoVehiculo, tipoCoche;
		String marca, modelo, bastidor, color, matricula, TipoCoche;
		boolean claveMetodos; //Se usa para saber si se han introducido los datos
		int claveSwitch; //clave para entrar a switches para pedir datos
		
		//Variables para introducir clientes
		String nombre, ap1, ap2, dni;
		
		//Variables para introducir alquileres
		int diasAlquiler;
		
		//Se introducen los datos para el menu
		opciones[0] = "Comprar vehiculo";
		opciones[1] = "Matricular vehiculo";
		opciones[2] = "Alquilar vehiculo";
		opciones[3] = "Lista de vehiculos";
		opciones[4] = "Lista de vehiculos alquilados";
		opciones[5] = "Introducir cliente";
		opciones[6] = "Listado clientes";
		opciones[7] = "Dar de baja alquiler";
		opciones[8] = "Dar de baja vehiculo";
		opciones[9] = "Dar baja cliente";
		opciones[10] = "Salir";
		
		respuestas[0] = "1";
		respuestas[1] = "2";
		respuestas[2] = "3";
		respuestas[3] = "4";
		respuestas[4] = "5";
		respuestas[5] = "6";
		respuestas[6] = "7";
		respuestas[7] = "8";
		respuestas[8] = "9";
		respuestas[9] = "10";
		respuestas[10] = "11";
		
		do {
			
			//*****Se muestra el menu*****
			claveMenu = Metodos.menu(opciones, respuestas, teclado);
			
			switch(claveMenu) {
			
			case "1":
				
				//int id, String marca, String modelo, String bastidor, String color, int numPlazas, String tipoCoche
				System.out.println("Si va a introducir un coche pulse 1, furgoneta pulse 2, cami�n pulse 3: ");
				tipoVehiculo = teclado.nextInt();
				//Se valida
				Metodos.validarNum(tipoVehiculo, 1, 3, teclado);
				
				//Se piden los datos del vehiculo genericos
				teclado.nextLine();
				
				System.out.println("Introduzca la marca: ");
				marca = teclado.nextLine();
				System.out.println("Introduzca el modelo: ");
				modelo = teclado.nextLine();
				System.out.println("Introduzca el n�mero de bastidor: ");
				bastidor = teclado.nextLine();
				System.out.println("Introduzca el color: ");
				color = teclado.nextLine();
				
				switch(tipoVehiculo) {
				
				case 1: //*****Coche*****
					System.out.println("Introduzca el n�mero de plazas: ");
					numPlazas = teclado.nextInt();
					//Se valida
					Metodos.validarNum(numPlazas, 0, 8, teclado);
					
					//Se pregunta el tipo de coche
					System.out.println("Si es b�sico pulse 1, 2 si es berlina o 3 si es de lujo: ");
					tipoCoche = teclado.nextInt();
					//Se valida
					Metodos.validarNum(tipoCoche, 1, 3, teclado);
					teclado.nextLine();
					
						switch(tipoCoche) { //Se introduce en la coleccion de coches
						
						case 1: empresa.ComprarCoche(marca, modelo, bastidor, color, numPlazas, "BASICO"); break;
						case 2: empresa.ComprarCoche(marca, modelo, bastidor, color, numPlazas, "BERLINA"); break;
						case 3: empresa.ComprarCoche(marca, modelo, bastidor, color, numPlazas, "LUJO"); break;
						
						}
					
					break;
					
				case 2: //*****Furgoneta*****
					System.out.println("Introduzca el n�mero de plazas: ");
					numPlazas = teclado.nextInt();
					System.out.println("introduzca el n�mero de kilos: ");
					numKilos = teclado.nextInt();
					//Se valida
					Metodos.validarNum(numKilos, 0, 1000000, teclado);
					teclado.nextLine();
					
					//Se introduce en la coleccion de coches
					empresa.ComprarFurgoneta(marca, modelo, bastidor, color, numPlazas, numKilos);
					
					break;
					
				case 3: //*****Cami�n*****
					System.out.println("introduzca el n�mero de kilos: ");
					numKilos = teclado.nextInt();
					//Se valida
					Metodos.validarNum(numKilos, 0, 1000000, teclado);
					teclado.nextLine();
					
					//Se introduce en la coleccion de coches
					empresa.ComprarCamion(marca, modelo, bastidor, color, numKilos);
					
					break;
					
				}
				
				//Parada
				System.out.println("Vehiculo introducido! Pulse para continuar");
				teclado.nextLine();
				
				break;
			
			case "2":
				
				//Se piden los datos para poder matricular 
				System.out.println("Introduzca el id del coche que quiere matricular: ");
				id = teclado.nextInt();
				//Se valida
				while(id < 0) {
					System.out.println("N�mero invalido, tiene que se mayor que 0, introduzca de nuevo: ");
					id = teclado.nextInt();
				}
				teclado.nextLine();
				
				System.out.println("Introduzca la matricula: ");
				matricula = teclado.nextLine();
				
				//Se introduce la matricula
				claveMetodos = empresa.MatricularVehiculo(id, matricula);
				
				//Se comprueba si se han introducido los datos para mandar el mensaje al usuario
				if (claveMetodos == true) {
					
					System.out.println("Matricula introducida! Pulse para continuar");
					teclado.hasNextLine();
					
				}
				else {
					
					System.out.println("La matricula no se ha introducido, puede ser porque no existe el id, ya est� matriculado o ya exista un vehiculo con esta matricula." + 
					"\nPulse para continuar");
					teclado.nextLine();
					
				}
				
				break;
				
			case "3":
				
				//Se pregunta si se quiere introducir el cliente antes
				System.out.println("�Quiere introducir al cliente primero? Pulse 1 si quiere, 2 si no quiere: ");
				claveSwitch = teclado.nextInt();
				//Se valida
				Metodos.validarNum(claveSwitch, 1, 2, teclado);
				teclado.nextLine();
				
				switch(claveSwitch) {
				
				case 1: //Se introduce cliente
					
					//Se piden los datos del cliente
					System.out.println("Introduzca el dni: ");
					dni = teclado.nextLine();
					//Se valida el dni
					dni = Metodos.validarDNI(dni, teclado);
					
					System.out.println("Introduzca el nombre: ");
					nombre = teclado.nextLine();
					System.out.println("Introduzca el primer apellido: ");
					ap1 = teclado.nextLine();
					System.out.println("Introduzca el segundo apellido: ");
					ap2 = teclado.nextLine();
					
					//Se introduce el cliente
					claveMetodos = empresa.IntroducirCliente(nombre, ap1, ap2, dni);
					
					//Se comprueba si se ha introducido
					if (claveMetodos == true) {
						
						System.out.println("Cliente introducido! Pulse para continuar");
						teclado.nextLine();
						
						//Se piden los datos del alquiler
						System.out.println("Introduzca el identificador del vehiculo: ");
						id = teclado.nextInt();
						//Se valida
						while(id < 0) {
							System.out.println("N�mero invalido, tiene que se mayor que 0, introduzca de nuevo: ");
							id = teclado.nextInt();
						}
						teclado.nextLine();
						
						System.out.println("Introduzca el numero de d�as: ");
						diasAlquiler = teclado.nextInt();
						//Se valida
						while(diasAlquiler < 0) {
							System.out.println("N�mero invalido, tiene que se mayor que 0, introduzca de nuevo: ");
							diasAlquiler = teclado.nextInt();
						}
						teclado.nextLine();
						
						//Se realiza el alquiler
						claveMetodos = empresa.AlquilarVehiculo(id, dni, diasAlquiler);
						
						//Se comprueba que se ha realizado el alquiler
						if (claveMetodos == true) {
							
							System.out.println("El alquiler se ha realizado con exito! Pulse para continuar");
							teclado.hasNextLine();
							
						}
						else {
							
							System.out.println("El alquiler no se ha podido realizar, se debe a una de las siguientes causas:" 
									+ "\nNo existe el vehiculo."
									+ "\nNo esta matriculado el vehiculo."
									+ "\n\nPulse para continuar");
							teclado.nextLine();
							
						}
						
						
					}
					else {
						
						System.out.println("Cliente no introducido, se debe a que ya existe el dni."
								+ "\nPulse para continuar");
						teclado.nextLine();
						
					}
					
					break;
					
				case 2: //No se introduce cliente
					
					//Se piden los datos del alquiler
					System.out.println("Introduzca el identificador del vehiculo: ");
					id = teclado.nextInt();
					//Se valida
					while(id < 0) {
						System.out.println("N�mero invalido, tiene que se mayor que 0, introduzca de nuevo: ");
						id = teclado.nextInt();
					}
					teclado.nextLine();
					
					System.out.println("Introduzca el numero de d�as: ");
					diasAlquiler = teclado.nextInt();
					//Se valida
					while(diasAlquiler < 0) {
						System.out.println("N�mero invalido, tiene que se mayor que 0, introduzca de nuevo: ");
						diasAlquiler = teclado.nextInt();
					}
					teclado.nextLine();
					
					System.out.println("Introduzca el dni del cliente: ");
					dni = teclado.nextLine();
					dni = Metodos.validarDNI(dni, teclado);
					
					//Se realiza el alquiler
					claveMetodos = empresa.AlquilarVehiculo(id, dni, diasAlquiler);
					
					//Se comprueba que se ha realizado el alquiler
					if (claveMetodos == true) {
						
						System.out.println("El alquiler se ha realizado con exito! Pulse para continuar");
						teclado.hasNextLine();
						
					}
					else {
						
						System.out.println("El alquiler no se ha podido realizar, se debe a una de las siguientes causas:" 
								+ "\nNo existe el vehiculo."
								+ "\nNo esta matriculado el vehiculo."
								+ "\nNo existe el cliente."
								+ "\nYa esta alquilado el vehiculo."
								+ "\n\nPulse para continuar");
						teclado.nextLine();
						
					}
					
					break;
				
				}
				
				break;
				
			case "4":
				
				empresa.ListadoVehiculos();
				
				//Parada
				System.out.println("Pulse para continuar");
				teclado.hasNextLine();
				
				break;
				
			case "5":
				
				empresa.ListadoVehiculosAlquilados();
				
				//Parada
				System.out.println("Pulse para continuar");
				teclado.hasNextLine();
				
				break;
				
			case "6":
				
				//Se piden los datos del cliente
				System.out.println("Introduzca el dni: ");
				dni = teclado.nextLine();
				//Se valida el dni
				dni = Metodos.validarDNI(dni, teclado);
				
				System.out.println("Introduzca el nombre: ");
				nombre = teclado.nextLine();
				System.out.println("Introduzca el primer apellido: ");
				ap1 = teclado.nextLine();
				System.out.println("Introduzca el segundo apellido: ");
				ap2 = teclado.nextLine();
				
				//Se introduce el cliente
				claveMetodos = empresa.IntroducirCliente(nombre, ap1, ap2, dni);
				
				//Se comprueba si se ha introducido
				if (claveMetodos == true) {
					
					System.out.println("Cliente introducido! Pulse para continuar");
					teclado.nextLine();
					
				}
				else {
					
					System.out.println("Cliente no introducido, se debe a que ya existe el dni."
							+ "\nPulse para continuar");
					teclado.nextLine();
					
				}
				
				break;
				
			case "7":
				
				empresa.ListadoClientes();
				
				//Parada
				System.out.println("Pulse para continuar");
				teclado.hasNextLine();
				
				break;
				
			case "8":
					
					//Se piden los datos
					System.out.println("Introduzca el identificador del alquiler a dar de baja: ");
					id = teclado.nextInt();
					//Se valida
					while(id < 0) {
						System.out.println("N�mero invalido, tiene que se mayor que 0, introduzca de nuevo: ");
						id = teclado.nextInt();
					}
					teclado.nextLine();
					
					claveMetodos = empresa.BajaAlquiler(id);
					
					//Se comprueba si se ha dado de baja
					if (claveMetodos == true) {
						
						System.out.println("El alquiler se ha dado de baja! Pulse para continuar");
						teclado.nextLine();
						
					}
					else {
						
						System.out.println("El alquiler no se ha podido dar de baja, el id no existe. Pulse para continuar");
						teclado.nextLine();
						
					}
				
				break;
				
			case "9":
				
				//Se piden los datos
				System.out.println("Introduzca el identificador del vehiculo a dar de baja: ");
				id = teclado.nextInt();
				//Se valida
				while(id < 0) {
					System.out.println("N�mero invalido, tiene que se mayor que 0, introduzca de nuevo: ");
					id = teclado.nextInt();
				}
				teclado.nextLine();
				
				claveMetodos = empresa.BajaVehiculo(id);
				
				//Se comprueba si se ha dado de baja
				if (claveMetodos == true) {
					
					System.out.println("El vehiculo se ha dado de baja! Pulse para continuar");
					teclado.nextLine();
					
				}
				else {
					
					System.out.println("El vehiculo no se ha podido dar de baja, el id no existe o est� alquilado. Pulse para continuar");
					teclado.nextLine();
					
				}
				
				break;
				
			case "10":
				
				//Se piden los datos
				System.out.println("Introduzca el dni del cliente que quiere dar de baja: ");
				dni = teclado.nextLine();
				
				claveMetodos = empresa.BajaCliente(dni);
				
				//Se comprueba si se ha dado de baja
				if (claveMetodos == true) {
					
					System.out.println("El cliente se ha dado de baja! Pulse para continuar");
					teclado.nextLine();
					
				}
				else {
					
					System.out.println("El cliente no se ha podido dar de baja, el dni no existe o esta alquilando un vehiculo. Pulse para continuar");
					teclado.nextLine();
					
				}
				
				break;
				
				
			case "11":
				
				claveSalir = false;
				
				break;
				
			default:
				System.out.println("N�mero no valido, introduzca de nuevo: ");
				
				break;
			}
			
		} while(claveSalir == true);
		
		
		teclado.close();
		
	}

}
