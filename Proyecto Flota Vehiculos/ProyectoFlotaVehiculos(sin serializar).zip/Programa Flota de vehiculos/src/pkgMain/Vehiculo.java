package pkgMain;

public abstract class Vehiculo implements Comparable<Vehiculo>{

	public Vehiculo(int id, String marca, String modelo, String bastidor, String color) {
		
		this.id = id;
		this.marca = marca;
		this.modelo = modelo;
		this.bastidor = bastidor;
		this.color = color;
		
	}
	
	public String toString () {
		
		String frase = "-ID: " + id +
				"\n-Marca: " + marca +
				"\n-Modelo: " + modelo +
				"\n-Bastidor: " + bastidor +
				"\n-Color: " + color +
				"\n-Matricula: " + matricula +
				"\n--Precio por dia: " + PrecioAlquiler();
		
		return frase;
		
	}

	//Propiedades
	private int id;
	private String marca;
	private String modelo;
	private String bastidor;
	private String color;
	private String matricula = null;
	private boolean EstadoAlquiler = false;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public String getBastidor() {
		return bastidor;
	}
	public void setBastidor(String bastidor) {
		this.bastidor = bastidor;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	
	public boolean isEstadoAlquiler() {
		return EstadoAlquiler;
	}

	public void setEstadoAlquiler(boolean estadoAlquiler) {
		EstadoAlquiler = estadoAlquiler;
	}

	public abstract double PrecioAlquiler(int dias);
	
	public abstract double PrecioAlquiler();
	
	@Override
	public int compareTo (Vehiculo o) {
		
		int comparador;
		
		if (this.id > o.getId()) {
			
			comparador = 1;
			
		}
		else {
			
			comparador = -1;
			
		}
		
		return comparador;
		
	} 
	
}
