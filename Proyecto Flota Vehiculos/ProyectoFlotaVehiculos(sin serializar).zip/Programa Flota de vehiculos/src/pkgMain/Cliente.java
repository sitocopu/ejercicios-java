package pkgMain;

public class Cliente implements Comparable<Cliente>{

	public Cliente(String nombre, String ap1, String ap2, String dni) {
		super();
		this.nombre = nombre;
		this.ap1 = ap1;
		this.ap2 = ap2;
		DNI = dni;
	}
	
	public String toString() {
		
		String frase = "-Nombre: " + nombre +
				"\n-Apellidos: " + ap1 + " " + ap2 + 
				"\n-DNI: " + DNI;
		
		return frase;
		
	}
	
	
	//Propiedades
	private String nombre;
	private String ap1;
	private String ap2;
	private String DNI;
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getAp1() {
		return ap1;
	}
	public void setAp1(String ap1) {
		this.ap1 = ap1;
	}
	public String getAp2() {
		return ap2;
	}
	public void setAp2(String ap2) {
		this.ap2 = ap2;
	}
	public String getDni() {
		return DNI;
	}
	public void setDni(String dni) {
		DNI = dni;
	}

	@Override
	public int compareTo(Cliente o) {
		// TODO Auto-generated method stub	
		int comparador;
		
		comparador = this.nombre.compareTo(o.nombre); //Nos fijamos en el nombre para ordenar
		
		if (this.nombre.compareTo(o.nombre) == 0) { //Si el nombre es igual, en el apellido 1
			
			comparador = this.ap1.compareTo(o.ap1);
			
			if (this.ap1.compareTo(o.ap1) == 0) { //Si el apellido es igual, en el segundo apellido
				
				comparador = this.ap2.compareTo(o.ap2);
				
			}			
		}
		
		
		return comparador;
	}

}
