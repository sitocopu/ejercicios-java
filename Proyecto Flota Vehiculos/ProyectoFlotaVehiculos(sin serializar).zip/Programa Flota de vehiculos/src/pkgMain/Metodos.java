package pkgMain;

import java.util.Scanner;

public class Metodos {
	
	/**
	 * M�todo para mostrar menu y devolver la respuesta escogida por el usuario
	 * @param opciones Vector con el texto de las opciones
	 * @param valores Vector con los valores que el usuario a de introducir
	 * @param titulo String con el titulo del menu
	 * @return Devuelve el valor elegido por el usuario
	 */
	
	public static String menu(String[] opciones, String[] valores, String titulo, Scanner teclado) {
		
		String clave; //Variable que almacena la opcion elegida por el usuario
		int valido = 0; //Variable para validar
		
		int opcionLong, valoresLong; //Variables para almacenar la longitud
		int totalLong; //Variable para almacenar la longitud total
		int numAsteriscos; //Variable que almacena el numero de asteriscos
		
		//***********************--TITULO--***********************
		
		//Se recorre para ver cual es la opcion mas larga
		
		opcionLong = opciones[0].length();
		valoresLong = valores[0].length();
		
		for (int i = 0; i <= opciones.length - 1; i++) {
			
			if (opcionLong < opciones[i].length()) { //Se comprueba que sea mayor 
				
				opcionLong = opciones[i].length();
				
			}
			
			if (valoresLong < valores[i].length()) { //Se comprueba que sea mayor
				
				valoresLong = valores[i].length();
				
			}
			
		}
		
		//Se calculan los datos para que salga centrado
		
		totalLong = valoresLong + opcionLong + 1;
		
		numAsteriscos = totalLong - titulo.length();
		
		//Se muestran los asteriscos antes del titulo
		for (int i = 1; i <= numAsteriscos/2; i++) {
			
			System.out.print("*");
			
		}
		
		System.out.print(titulo);
		
		//Se muestran los asteriscos despues del titulo
		for (int i = 1; i <= numAsteriscos/2; i++) {
			
			System.out.print("*");
			
		}
		
		System.out.println("");

		//***********************--PROCESO DEL MENU--***********************
		
		//Se muestran las opciones
		for (int i = 0; i <= opciones.length - 1; i++) {
			
			System.out.println(valores[i] + "-" + opciones[i]);
			
		}
		
		//Se pide la opcion al usuario
		System.out.println("Introduzca la opci�n que desea ejecutar: ");
		clave = teclado.nextLine();
		
		do {
			
			//Se valida
			for (int i = 0; i <= valores.length - 1; i++) {
				
				if (clave.equals(valores[i])) {
					
					valido = 1;
					
				}
				
			}
			
			if (valido == 0) {
				
				System.out.println("Dato inv�lido, introduzca de nuevo: ");
				clave = teclado.nextLine();
				
			}
			
		} while (valido == 0);
		
		
		return clave;
	}

	/**
	 * M�todo para mostrar menu y devolver la respuesta escogida por el usuario
	 * @param opciones Vector con el texto de las opciones
	 * @param valores Vector con los valores que el usuario a de introducir
	 * @return Devuelve el valor elegido por el usuario
	 */
	
	public static String menu(String[] opciones, String[] valores, Scanner teclado) {
		return menu(opciones, valores, "Menu", teclado);
	}

	public static String validarDNI (String dni, Scanner teclado) {
		
		String numeros;
		int numDNI;
		String letra;
		String letraValida;
		String alfabeto;
		int posicionLetra;

		
		do {
				
			while (!(dni.length() == 9)) {
				
				System.out.println("Dato erroneo, introduzca de nuevo: ");
				dni = teclado.nextLine();
				
			}
			
			numeros = dni.substring(0, 8);
			numDNI = Integer.parseInt(numeros);
			letra = dni.substring(8);
			letra = letra.toUpperCase();
					
			//Se procesan los datos
			 
			alfabeto = "TRWAGMYFPDXBNJZSQVHLCKE";
			
			posicionLetra = numDNI%23;
			
			//Se coge la letra de la cadena del alfabeto
			letraValida = alfabeto.substring(posicionLetra, posicionLetra + 1);	
		
		
			if (!letraValida.equals(letra)) {
				
				System.out.println("Dato erroneo, introduzca de nuevo: ");
				dni = teclado.nextLine();
			}
		
		} while(!letraValida.equals(letra));
		
		
		return dni;
		
	}

	/**
	 * M�todo para validar un n�mero
	 * @param numero N�mero a validar
	 * @param rangoMin N�mero m�nimo posible
	 * @param rangoMax N�mero m�ximo posible
	 * @return N�mero validado
	 */
	
	public static int validarNum (int numero, int rangoMin, int rangoMax, Scanner teclado) {
				
		//Se valida el dato
		while (numero < rangoMin || numero > rangoMax) {
			
			System.out.println("Dato incorrecto, introduzca de nuevo (tiene que estar entre " + rangoMin + " y " + rangoMax + "): ");
			numero = teclado.nextInt();
			
		}
		
		
		//Se devuelve el dato
		return numero;
	}
	
	
}
