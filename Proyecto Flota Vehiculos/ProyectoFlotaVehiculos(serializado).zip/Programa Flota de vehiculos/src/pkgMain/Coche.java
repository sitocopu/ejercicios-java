package pkgMain;

public class Coche extends Vehiculo {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public Coche(int id, String marca, String modelo, String bastidor, String color, int numPlazas, String tipoCoche) {
		super(id, marca, modelo, bastidor, color);
		this.numPlazas = numPlazas;
		this.tipoCoche = tipoCoche;
	}
	
	
	//Propiedades
		private int numPlazas;
		private String tipoCoche; //Puede ser b�sico, berlina y lujo.
		
	
	public int getNumPlazas() {
		return numPlazas;
	}
	public void setNumPlazas(int numPlazas) {
		this.numPlazas = numPlazas;
	}
	public String getTipoCoche() {
		return tipoCoche;
	}
	public void setTipoCoche(String tipoCoche) {
		this.tipoCoche = tipoCoche;
	}
	
	
	@Override
	public double PrecioAlquiler(int dias) {
		//Variables
		double precioDia;
		double precioFinal;
		
		//Se calculan los datos
		precioDia = 50 + (this.numPlazas*5);
		
		if (this.tipoCoche == "BERLINA") {
			
			precioDia = precioDia + (precioDia*0.15);
			
		}
		
		else if (this.tipoCoche == "LUJO") {
			
			precioDia = precioDia + (precioDia*0.30);
			
		}
		
		//El precio final sera la multiplicacion de los dias por el precio de un dia
		precioFinal = precioDia * dias;
		
		return precioFinal;
	}

	@Override
	public double PrecioAlquiler() {
		// TODO Auto-generated method stub
		return PrecioAlquiler(1);
	}
	
}
