package pkgMain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;

public class Empresa implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public Empresa() {
		// TODO Auto-generated constructor stub
	}
	
	//Propiedades
	 private ArrayList<Cliente> clientes= new ArrayList<Cliente>();
	 private ArrayList<Vehiculo> vehiculos= new ArrayList<Vehiculo>();
	 private ArrayList<Alquiler> alquileres = new ArrayList<Alquiler>();
	 
	 
	public Cliente getCliente( int i) {
		return clientes.get(i);
	}
	public void setCliente(Cliente cliente) {
		this.clientes.add(cliente);
	}
	public Vehiculo getVehiculos(int i) {
		return vehiculos.get(i);
	}
	public void setVehiculos(Vehiculo vehiculo) {
		this.vehiculos.add(vehiculo);
	}
	public Alquiler getAlquiler( int i) {
		return alquileres.get(i);
	}
	public void setAlquiler(Alquiler alquiler) {
		this.alquileres.add(alquiler);
	}

	/**
	 * Lista todos los vehiculos de la empresa
	 */
	public void ListadoVehiculos() {
		
		Collections.sort(vehiculos);
		
		for (Vehiculo a: this.vehiculos) {
			
			System.out.println(a);
			System.out.println("-----------------------");
			
		}
		
	}
		
	/**
	 * Lista los vehiculos alquilados, el cliente que alquila cada coche y el precio que le ha costado
	 */
	public void ListadoVehiculosAlquilados() {
			
		Vehiculo vehiculoAlquilado;
		Cliente clienteAlquila;
		
		Collections.sort(alquileres);
		
		for (Alquiler a: this.alquileres) {
			
			//Se crea el vehiculo y el cliente
			vehiculoAlquilado = a.getVehiculo();
			clienteAlquila = a.getCliente();
			
			//Se muestran los datos
			System.out.println("---Cliente---");
			System.out.println(clienteAlquila);
			System.out.println("--Precio alquiler: " + a.CalcularCoste());
			System.out.println("---" + vehiculoAlquilado.getClass().getSimpleName() + "---");
			System.out.println(vehiculoAlquilado);
			System.out.println("\n--Numero de d�as del alquiler: " + a.getDiasAlquiler());
			System.out.println("\n--Identificador de alquiler: " + a.getIdAlquiler());
			
			System.out.println("-----------------------");
			}
			
		}
	
	public void ComprarCoche(String marca, String modelo, String bastidor, String color, int numPlazas, String tipoCoche) {
		
		Vehiculo coche = new Coche((vehiculos.size() + 1), marca.toUpperCase(), modelo.toUpperCase(), bastidor.toUpperCase(), color.toUpperCase(), numPlazas, tipoCoche.toUpperCase());
		this.vehiculos.add(coche);
		
	}
	
	public void ComprarFurgoneta(String marca, String modelo, String bastidor, String color, int numPlazas, int numKilos) {
		
		Vehiculo coche = new Furgoneta((vehiculos.size() + 1), marca.toUpperCase(), modelo.toUpperCase(), bastidor.toUpperCase(), color.toUpperCase(), numPlazas, numKilos);
		this.vehiculos.add(coche);
		
	}
	
	public void ComprarCamion(String marca, String modelo, String bastidor, String color, int numKilos) {
		
		Vehiculo coche = new Camion((vehiculos.size() + 1), marca.toUpperCase(), modelo.toUpperCase(), bastidor.toUpperCase(), color.toUpperCase(), numKilos);
		this.vehiculos.add(coche);
		
	}

	/**
	 * Metodo para introducir un cliente
	 * @param nombre nombre
	 * @param ap1 apellido 1
	 * @param ap2 apellido 2
	 * @param dni dni del cliente
	 * @return devuelve true o false para saber si se ha introducido
	 */
	public boolean IntroducirCliente(String nombre, String ap1, String ap2, String dni) {
	
		//Variables
		boolean claveCliente = true;
		
		//Se comprueba que el dni no est� ya en la base de datos
		for (Cliente a: clientes) {
			
			if (a.getDni().compareTo(dni.toUpperCase()) == 0) {
				
				claveCliente = false;
				
			}
			
		}
		
		if (claveCliente == true) {
			
			Cliente cliente = new Cliente(nombre.toUpperCase(), ap1.toUpperCase(), ap2.toUpperCase(), dni.toUpperCase());
			clientes.add(cliente);
		
		}
		
		return claveCliente;
		
	}

	/**
	 * Metodo para alquilar un vehiculo a un cliente, devuelve true o false para comprobar si se ha introducido
	 * @param id id del vehiculo
	 * @param dni dni del cliente
	 * @param diasAlquiler dias a alquilar
	 * @return devuelve true o false para comprobar si se ha realizado el alquiler
	 */
	public boolean AlquilarVehiculo(int id, String dni, int diasAlquiler) {
		
		//Variables
		Vehiculo vehiculoAlquilar = null;
		Cliente clienteAlquila = null;
		boolean claveVehiculo = false, claveCliente= false, claveAlquiler = false;;
		
		//Buscamos el vehiculo y el cliente
		
		for (Cliente a: clientes) {
						
			if (a.getDni().compareTo(dni.toUpperCase()) == 0) {
				
				clienteAlquila = a;
				claveCliente = true;
				
			}
		}
		
		if(claveCliente == true) {
			
			for (Vehiculo a: vehiculos) {
				
				if (a.getId() == id && a.getMatricula() != null && a.isEstadoAlquiler() == false) { //Nos fijamos si esta matriculado
					
					//a.setEstadoAlquiler(true);
					vehiculoAlquilar = a;
					claveVehiculo = true;
						
				}
			}
			
		}
		
		//Se comprueba que tenemos tanto el vehiculo como el cliente para realizar el alquiler
		if (claveVehiculo == true && claveCliente == true) {
			
			Alquiler NuevoAlquiler = new Alquiler((alquileres.size() + 1), clienteAlquila, vehiculoAlquilar, diasAlquiler);
			alquileres.add(NuevoAlquiler);
			
			claveAlquiler = true;
		}
		
		return claveAlquiler;
		
	}
	
	/**
	 * Metodo que matricula un vehiculo
	 * @param id id del vehiculo a matricular
	 * @param matricula matricula que se le va a a�adir al vehiculo
	 * @return devuelve true o false para saber si se ha matriculado
	 */
	public boolean MatricularVehiculo(int id, String matricula) {
		
		//Variables
		boolean claveMatricular = true, claveMatricularBuena = false;
		
		//Se comprueba que la matricula no este ya registrada
		for (Vehiculo a: vehiculos) {
			
			if ((a.getMatricula() != null) && (a.getMatricula().equals(matricula.toUpperCase()))) {
				
				claveMatricular = false;
				
			}
			
		}
		
		//Se busca el vehiculo con el id correspondiente
		
		if (claveMatricular == true) { //Si ya esta matriculado el vehiculo no entra a buscar
		
			for (Vehiculo a: vehiculos) {
				
				if (a.getId() == id && a.getMatricula() == null) {
					
					a.setMatricula(matricula.toUpperCase());
					claveMatricularBuena = true;
					
				}
				
			}
			
		}
		
		return claveMatricularBuena;
	}		
	
	public boolean BajaAlquiler(int id) {
		
		//variables
		boolean claveBajaAlquiler = false;
		Alquiler baja = null;
		Vehiculo cocheAlquilado = null;
		
		//Se comprueba si existe un alquiler con ese id
		for (Alquiler a: alquileres) {
			
			if (a.getIdAlquiler() == id) {
				
				baja = a;
				cocheAlquilado = a.getVehiculo();
				cocheAlquilado.setEstadoAlquiler(false);
				
				//Se busca el vehiculo en la coleccion de vehiculos y se cambia su estado de alquiler
				vehiculos.set(vehiculos.indexOf(cocheAlquilado), cocheAlquilado);
				
			}
			
		}
		
		
		//Se da de baja
		claveBajaAlquiler = alquileres.remove(baja);
		
		return claveBajaAlquiler;
		
	}

	public boolean BajaVehiculo (int id) {
		
		//variables
		boolean claveBajaVehiculo = false, claveAlquiler = true;
		Vehiculo baja = null;
		
		//Se comprueba si existe un alquiler con ese id
		for (Vehiculo a: vehiculos) {
			
			if (a.getId() == id) {
				
				//Buscamos que no este el cliente en un alquiler
				for (Alquiler b: alquileres) {
					
					if (b.getVehiculo().equals(a) == true) {
						
						claveAlquiler = false;
						
					}
					
				}
				
				if (claveAlquiler == true) {
				
					baja = a;
					
				}
				
			}
			
		}
		
		//Se da de baja
		claveBajaVehiculo = vehiculos.remove(baja);
		
		return claveBajaVehiculo;

	}
	
	public void ListadoClientes () {
		
		Collections.sort(this.clientes);
		
		//Se muetran
		for (Cliente a: clientes) {
			
			System.out.println(a);
			System.out.println("-----------------------");
			
		}
		
	}
	
	public boolean BajaCliente (String dni) {
		
		//variables
		boolean claveBajaCliente = false, claveAlquiler = true;
		Cliente baja = null;
		
		//Se comprueba si existe un alquiler con ese id
		for (Cliente a: clientes) {
			
			if (a.getDni().compareTo(dni.toUpperCase()) == 0) {
				
				//Buscamos que no este el cliente en un alquiler
				for (Alquiler b: alquileres) {
					
					if (b.getCliente().equals(a) == true) {
						
						claveAlquiler = false;
						
					}
					
				}
				
				if (claveAlquiler == true) {
				
					baja = a;
					
				}
				
				
			}
			
		}
		
		//Se da de baja
		claveBajaCliente = clientes.remove(baja);
		
		return claveBajaCliente;

	}
	
	}
	
	
	

