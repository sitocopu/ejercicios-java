package pkgMain;

public class Camion extends Vehiculo {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public Camion(int id, String marca, String modelo, String bastidor, String color, int numKilos) {
		super(id, marca, modelo, bastidor, color);
		this.numKilos = numKilos;
	}

	
	//Propiedades
	private int numKilos;

	
	public int getNumKilos() {
		return numKilos;
	}

	public void setNumKilos(int numKilos) {
		this.numKilos = numKilos;
	}

	
	@Override
	public double PrecioAlquiler(int dias) {
		
		//Variables
		double precioDia;
		double precioFinal;
		
		//Se calculan los datos
		precioDia = 60;
		
		if (this.numKilos <= 1000) {
			
			precioDia = precioDia + 60;
			
		}
		
		else if (this.numKilos > 1000 && this.numKilos <= 2500) {
			
			precioDia = precioDia + 70;
			
		}
		
		else if (this.numKilos > 2500) {
			
			precioDia = precioDia + 80;
			
		}
		
		//El precio final sera la multiplicacion de los dias por el precio de un dia
		precioFinal = precioDia * dias;
		
		return precioFinal;

	}

	@Override
	public double PrecioAlquiler() {
		// TODO Auto-generated method stub
		return PrecioAlquiler(1);
	}
	
	

}
