package pkgMain;

public class Furgoneta extends Vehiculo {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public Furgoneta(int id, String marca, String modelo, String bastidor, String color, int numPlazas, int numKilos) {
		super(id, marca, modelo, bastidor, color);
		this.numPlazas = numPlazas;
		this.numKilos = numKilos;
	}
	
	
	//Propiedades
	private int numPlazas;
	private int numKilos;
	
	
	public int getNumPlazas() {
		return numPlazas;
	}
	public void setNumPlazas(int numPlazas) {
		this.numPlazas = numPlazas;
	}
	public int getNumKilos() {
		return numKilos;
	}
	public void setNumKilos(int numKilos) {
		this.numKilos = numKilos;
	}
	
	
	@Override
	public double PrecioAlquiler(int dias) {
		
		//Variables
		double precioDia;
		double precioFinal;
		
		//Se calculan los datos
		precioDia = 60 + (this.numPlazas*3);
		
		if (this.numKilos <= 500) {
			
			precioDia = precioDia + 20;
			
		}
		
		else if (this.numKilos > 500 && this.numKilos <= 1000) {
			
			precioDia = precioDia + 50;
			
		}
		
		else if (this.numKilos > 1000) {
			
			precioDia = precioDia + 60;
			
		}
		
		//El precio final sera la multiplicacion de los dias por el precio de un dia
		precioFinal = precioDia * dias;
		
		return precioFinal;
		
	}
	
	@Override
	public double PrecioAlquiler() {
		// TODO Auto-generated method stub
		return PrecioAlquiler(1);
	}
	
	
}
