package pkgEj16;
import java.util.Scanner;
public class Ej16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		String texto; //Variable para guardar el nombre completo
		String nombre; //Variable para almacenar el nombre
		String apellidos; //variable para almacenar los apellidos
		
		//Se pide el nombre
		System.out.println("Introduzca su nombre en el formato apellidos, nombre: ");
		texto = teclado.nextLine();
		
		//Se valida el dato
		while (texto.indexOf(",") == -1 || texto.indexOf(",") == texto.length() - 1) {
			
			System.out.println("Dato no v�lido, introduzca de nuevo: ");
			texto = teclado.nextLine();
			
		}
		
		//Se procesan los datos
		
		nombre = texto.substring((texto.indexOf(",") + 1), texto.length());
		apellidos = texto.substring(0, texto.indexOf(","));
		
		//Se muestran los datos
		System.out.println(nombre + " " + apellidos);
		
		teclado.close();
		
	}

}
