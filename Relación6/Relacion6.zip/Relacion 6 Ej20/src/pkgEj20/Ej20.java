package pkgEj20;
import java.util.Scanner;
public class Ej20 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		 int dniNum; //Variable para almacenar los ocho numeros del dni
		 int posicionLetra; //Variable para saber la posicion de la letra en el alfabeto
		 String letra; //Variable para almacenar la letra
		 String alfabeto; //Variable para guardar todas las letras y coger la que le corresponda
		 
		 //Se pide el dni sin letra
		 System.out.println("Introduzca los ocho digitos del dni: ");
		 dniNum = teclado.nextInt();
		 
		 //Se valida el dato
		 while (dniNum/10000000 != 7) {
			 
			 System.out.println("Dato invalido, introduzca de nuevo: ");
			 dniNum = teclado.nextInt();
			 
		 }		
		 
		 //Se procesan los datos
		 
		alfabeto = "TRWAGMYFPDXBNJZSQVHLCKE";
		
		posicionLetra = dniNum%23;
		
		//Se coge la letra de la cadena del alfabeto
		letra = alfabeto.substring(posicionLetra, posicionLetra + 1);	
		
		//Se muestra el dni completo
		System.out.println("El dni es: " + dniNum + letra);
		
		teclado.close();
		
		
		
		
		
	}

}
