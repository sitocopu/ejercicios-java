package pkgEj21;
import java.util.Scanner;
public class Ej21 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		String texto; //Variable para almacenar el texto
		String textoCodificado = ""; //Variable para almacenar el texto codificado
		String alfabeto; //Variable para almacenar todas las letras del alfabeto
		int aux; 
		
		//Se pide el texto al usuario
		System.out.println("Introduzca el texto: ");
		texto = teclado.nextLine();
		
		//Se procesan los datos
		
		texto = texto.toLowerCase();
		alfabeto = "abcdefghijklmn�opqrstuvwxyz";
		
		for (int i = 0; i <= texto.length() - 1; i++) {
			
			aux = alfabeto.lastIndexOf(texto.substring(i, i + 1));
			
			if (aux != -1) { //Si esta en el alfabeto se cambia
				
				if (aux == alfabeto.length()) { //Si es la z se pasa a la a
					
					textoCodificado = textoCodificado + "a";
					
				}
				
				else {
					
					textoCodificado = textoCodificado + alfabeto.substring(aux + 1, aux + 2);	
					
				}
				
			}
			
			else { //Si no esta es un espacio o un punto, se deja igual
				
				textoCodificado = textoCodificado + texto.substring(i, i + 1);
				
			}
			
		}
		
		//Se muestran los datos
		System.out.println(textoCodificado.toUpperCase());
		
		
		teclado.close();
		
		
		
		
	}

}
