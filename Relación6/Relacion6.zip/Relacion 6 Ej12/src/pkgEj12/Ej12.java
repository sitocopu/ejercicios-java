package pkgEj12;
import java.util.Scanner;
public class Ej12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		int cantidad; //Variable para almacenar la cantidad de numeros que quiere introducir
		int ordenar; //Variable para almacenar la forma de ordenar
		String aux; //Variable para procesar datos
		String paso; //Variable para poder guardar el intro despues de pedir un numerico
		String palabras[]; //Cadena para almacenar los numeros
		
		//Se pide la cantidad al usuario
		System.out.println("Introduzca la cantidad de palabras que quiere introducir: ");
		cantidad = teclado.nextInt();
		paso = teclado.nextLine();
		
		//Se valida
		while (cantidad < 0) {
			
			System.out.println("Dato no v�lido, introduzca de nuevo: ");
			cantidad = teclado.nextInt();
			
		}
		
		//Se pregunta si quiere ordenar de mayor a menor o al reves
		System.out.println("Si quiere ordenar de mayor a menor introduzca 1, sino 0: ");
		ordenar = teclado.nextInt();
		
		//Se valida
		while (!(ordenar == 0) && !(ordenar == 1)) {
			
			System.out.println("Dato no v�lido, introduzca de nuevo: ");
			ordenar = teclado.nextInt();
			
		}
		
		paso = teclado.nextLine();
		
		//Se crea la variable
		palabras = new String[cantidad];
		
		//Se introducen los datos
		
		System.out.println("Introduzca las palabras: ");
		for (int i = 0; i <= cantidad - 1; i++) {
			
			System.out.println("Palabra " + (i + 1) + ": ");
			palabras[i] = teclado.nextLine();
			
		}
		
		//Se procesan los datos
		for (int i = 0; i <= cantidad - 1; i++) {
			
			for (int y = 0; y <= cantidad - 1; y++) {
				
				if (ordenar == 1) { //De mayor a menor
					
					if (palabras[i].compareTo(palabras[y]) < 0) {
						
						aux = palabras[i];
						palabras[i] = palabras[y];
						palabras[y] = aux;
						
					}
					
				}
				
				else { //De menor a mayor
					
					if (palabras[i].compareTo(palabras[y]) > 0) {
						
						aux = palabras[i];
						palabras[i] = palabras[y];
						palabras[y] = aux;
						
					}
					
				}
				
			}
			
		}
		
		//Se muestran los datos
		for (int i = 0; i <= cantidad - 1; i++) {
			
			if (!(i == cantidad - 1)) {
				
				System.out.print(palabras[i] + " -- ");
			
			}
			
			else {
				
				System.out.print(palabras[i]);
				
			}
			
		}
		
		teclado.close();
		
		
		
		
		
		
		
		
		
		
		
	}

}
