package pkgEJ14;
import java.util.Scanner;
public class Ej14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		int cantidadAlum; //Variable para almacenar la cantidad de alumnos a introducir
		int asignaturas; //Variable para saber el numero de asignaturas
		double media; //Variable para almacenar la media
		String nombres[][]; //Cadena para guardar los nombres
		String paso; //Variable para guardar el intro
		String aux; //variable para ordenar nombres y numeros
		
		//Se pide el numero de alumnos
		System.out.println("Introduzca la cantidad del alumnos que va a introducir: ");
		cantidadAlum = teclado.nextInt();
		
		//Se valida
		while (cantidadAlum < 0) {
			
			System.out.println("Dato no valido, introduzca de nuevo: ");
			cantidadAlum = teclado.nextInt();
			
		}
		
		//Se pide el numero de asignaturas
		System.out.println("Introduzca el numero de asignaturas: ");
		asignaturas = teclado.nextInt();
		
		//Se crean las cadenas
		nombres = new String[asignaturas + 1][cantidadAlum];
		paso = teclado.nextLine();
		
		//Se introducen los alumnos y sus respectivas notas
		for (int i = 0; i<= cantidadAlum - 1; i++) {
			
			System.out.println("Introduzca el nombre del alumno " + (i+1) + ": ");
			nombres[0][i] = teclado.nextLine();
			
			System.out.println("Introduzca sus notas: ");
			
			for (int y = 1; y <= asignaturas; y++) {
				
				nombres[y][i] = teclado.nextLine();
			
				//Se valida
				while (!(nombres[y][i].equals("1")) && !(nombres[y][i].equals("2")) &&!(nombres[y][i].equals("3")) &&!(nombres[y][i].equals("4")) &&!(nombres[y][i].equals("5")) &&!(nombres[y][i].equals("6")) &&!(nombres[y][i].equals("7")) &&!(nombres[y][i].equals("8")) &&!(nombres[y][i].equals("9")) &&!(nombres[y][i].equals("10"))) {
					
					System.out.println("Dato no valido, introduzca de nuevo: ");
					nombres[y][i] = teclado.nextLine();
					
				} 
				
			}
			
		}
		
		//Se ordenan los datos
		for (int i = 0; i <= cantidadAlum - 1; i++) {
			
			for (int y = 0; y <= cantidadAlum - 1; y++) {
				
				if (nombres[0][i].compareTo(nombres[0][y]) < 0) {
					
					//Se ordena el nombre
					aux = nombres[0][i];
					nombres[0][i] = nombres[0][y];
					nombres[0][y] = aux;
					
					//Se ordena sus notas
					for (int x = 1; x <= asignaturas; x++) {
						
						aux = nombres[x][i];
						nombres[x][i] = nombres[x][y];
						nombres[x][y] = aux;
					
					}
						
				}
				
			}
			
		}
		
		//Se declara y se crea una variable cadena para almacenar las notas y hacer la media a mostrar
		double notas[] = new double[asignaturas];
		
		//Se muestran los datos
		for (int i = 0; i <= cantidadAlum - 1; i++) {
			
			System.out.print(nombres[0][i] + " --> ");
			
			for (int y = 1; y <= asignaturas; y++) { //Introducir datos en la cadena
				
				notas[y - 1] = Double.parseDouble(nombres[y][i]);
				
			}
			
			media = 0; //Se inicializa la media por cada alumno
			
			for (int y = 0; y <= asignaturas - 1; y++) { //Se suman las notas del alumno
				
				media = media + notas[y];
				
			}
			
			media = media/asignaturas; //Se calcula la media
			
			System.out.println(media);
			System.out.println("");
			
		}
		
		teclado.close();
		
		
		
		
		
		
	}

}
