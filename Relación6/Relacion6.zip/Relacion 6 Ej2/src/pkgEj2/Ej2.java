package pkgEj2;
import java.util.Scanner;
public class Ej2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in); // Lector
		
		int numAlum; //Numero de alumnos
		double notaCorte; //Variable para guardar la nota de corte
		String paso; //Variable para guardar los intros
		
		//Se piden los datos
		System.out.println("Introduzca el n�mero de alumnos que va a introducir: ");
		numAlum = teclado.nextInt();
		
		//Se valida el dato
		while (numAlum < 0) {
			
			System.out.println("Dato no v�lido, introduzca un valor positivo");
			numAlum = teclado.nextInt();
			
		}
		
		double[] notas = new double[numAlum]; //Se crea la cadena para guardar las notas
		String[] nombres = new String[numAlum]; //Cadena para guardar los nombres
		
		//Se piden las notas
		for (int i = 0; i <= (notas.length - 1); i++) {
			
			System.out.println("Introduzca el nombre del alumno " + (i+1) + ": "); //Se pide el nombre
			paso = teclado.nextLine();
			nombres[i] = teclado.nextLine();
			
			System.out.println("Introduzca la nota del alumno " + (i+1) + ": "); //Se pide la nota
			notas[i] = teclado.nextDouble();
			
			//Se valida el dato
			while (notas[i] < 0 || notas[i] > 10) {
				
				System.out.println("Dato no v�lido, introduzca un valor comprendido entre 0 y 10: ");
				notas[i] = teclado.nextDouble();
				
			}
			
		}
		
		//Se pide la nota de corte
		System.out.println("Introduzca la nota de corte: ");
		notaCorte = teclado.nextInt();
		
		//Se valida el dato
		while (notaCorte < 0) {
			
			System.out.println("Dato no v�lido, introduzca un valor positivo");
			notaCorte = teclado.nextInt();
			
		}
		
		//Se calculan las notas que superan la nota de corte
		for (int i = 0; i <= (notas.length - 1); i++) {
			
			if (notas[i] > notaCorte) {
				
				System.out.println(nombres[i] + " --> " + notas[i]);
				
			}
			
		}
		
		
		
	}

}
