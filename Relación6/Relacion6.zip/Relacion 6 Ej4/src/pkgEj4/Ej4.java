package pkgEj4;
import java.util.Scanner;
public class Ej4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in); //Lector
		
		int num; //Numero de filas que va a tener
		int num2; //Variable para guardar el numero de posiciones necesarias
		int espacios;
		
		System.out.println("Introduzca el numero de filas que quiere que tenga(minimo 3 y tiene que ser impar): ");
		num = teclado.nextInt();
		
		//Se valida
		while (num < 3 || num%2 == 0) {
			
			System.out.println("Dato no v�lido, introduzca de nuevo(tiene que ser positivo): ");
			num = teclado.nextInt();
			
		}
		
		String[] caracteres = new String[2]; //Cadena para guardar los tipos de caracteres para formar el cuadrado
		
		caracteres[0] = "*";
		caracteres[1] = " ";
		
		//Se calcula el numero de posiciones necesarias por fila
		num2 = num + 2;
		
		//Se muestra el triangulo
		for (int i = 1; i <= num; i++) { //Numero de filas
			 
			System.out.println("");
			espacios = num - i; //Espacios en cada fila
			
			if (i != num) { //Si no el la ultima tendra espacios
				
				for (int y = 1; y <= espacios; y++  ) { //Pone los espacios en blanco
					
					System.out.print(caracteres[1]);
					
				}
				
				for (int w = 1; w <= num2 - (espacios*2); w++) {
					
					System.out.print(caracteres[0]);
					
				}
				
				for (int y = 1; y <= espacios; y++  ) { //Pone los espacios en blanco
					
					System.out.print(caracteres[1]);
					
				}
			
			}
			
			else { //Si es la ultima no tiene espacios
				
				for (int x = 1; x <= num2; x++) {
					
					System.out.print(caracteres[0]);
					
				}
				
			}
			
		}
		
		
		
		
		
		
	}

}
