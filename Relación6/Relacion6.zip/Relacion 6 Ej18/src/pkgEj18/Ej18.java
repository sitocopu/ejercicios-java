package pkgEj18;
import java.util.Scanner;
public class Ej18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		String texto; //Variable para almacenar el texto dado
		String caracteres = " ,.;";
		int palabras = 0;
		
		//Se pide el texto
		System.out.println("Introduzca el texto: ");
		texto = teclado.nextLine();
		
		//Se procesan los datos
		for (int i = 0; i <= texto.length() - 1; i++) {
			
			if (caracteres.indexOf(texto.substring(i, i + 1)) != -1) {
				
				palabras++;
				
			}
			
		}
		
		
		//Se muestran los datos
		System.out.println("Hay " + palabras + " palabras.");
		
		teclado.close();
		
		
		
		
		
	}

}
