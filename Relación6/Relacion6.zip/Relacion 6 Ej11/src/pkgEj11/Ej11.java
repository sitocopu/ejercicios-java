package pkgEj11;
import java.util.Scanner;
public class Ej11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		int cantidad; //Variable para almacenar la cantidad de numeros que quiere introducir
		String aux; //Variable para procesar datos
		String paso; //Variable para poder guardar el intro despues de pedir un numerico
		String palabras[]; //Cadena para almacenar los numeros
		
		//Se pide la cantidad al usuario
		System.out.println("Introduzca la cantidad de palabras que quiere introducir: ");
		cantidad = teclado.nextInt();
		paso = teclado.nextLine();
		
		//Se valida
		while (cantidad < 0) {
			
			System.out.println("Dato no v�lido, introduzca de nuevo: ");
			cantidad = teclado.nextInt();
			
		}
		
		//Se crea la variable
		palabras = new String[cantidad];
		
		//Se introducen los datos
		
		System.out.println("Introduzca las palabras: ");
		for (int i = 0; i <= cantidad - 1; i++) {
			
			System.out.println("Palabra " + (i + 1) + ": ");
			palabras[i] = teclado.nextLine();
			
		}
		
		//Se procesan los datos
		for (int i = 0; i <= cantidad - 1; i++) {
			
			for (int y = 0; y <= cantidad - 1; y++) {
				
				if (palabras[i].compareTo(palabras[y]) < 0) {
					
					aux = palabras[i];
					palabras[i] = palabras[y];
					palabras[y] = aux;
					
				}
				
			}
			
		}
		
		//Se muestran los datos
		for (int i = 0; i <= cantidad - 1; i++) {
			
			if (!(i == cantidad - 1)) {
				
				System.out.print(palabras[i] + " -- ");
			
			}
			
			else {
				
				System.out.print(palabras[i]);
				
			}
			
		}
		
		teclado.close();
		
		
		
		
		
		
		
		
		
		
	}

}
