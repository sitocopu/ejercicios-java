package pkgEj9;
import java.util.Scanner;
public class Ej9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		int fila1, fila2, colum1, colum2; //Variables para almacenar las dimensiones de las matrices
		int matriz1[][], matriz2[][]; //Cadenas para almacenar los valores de las matrices
		int matrizResul[][]; //Cadena con la matriz resultante
		int cuenta; //Variable para ir calculando el valor que estara en una posicion de la matrizResul
		int aux;
		
		//Se piden los datos
		System.out.println("Introduzca las filas y las columnas de la primera matriz: ");
		fila1 = teclado.nextInt();
		
		//Se valida el dato
		while (fila1 < 0) {
			
			System.out.println("Dato no v�lido, no puede ser negativo, introduzca de nuevo: ");
			fila1 = teclado.nextInt();
			
		}
		
		colum1 = teclado.nextInt();
		
		//Se valida el dato
		while (colum1 < 0) {
			
			System.out.println("Dato no v�lido, no puede ser negativo, introduzca de nuevo: ");
			colum1 = teclado.nextInt();
			
		}
		
		//Segunda matriz
		System.out.println("Introduzca las filas y las columnas de la segunda matriz: ");
		fila2 = teclado.nextInt();
		
		//Se valida el dato
		while (fila2 < 0) {
			
			System.out.println("Dato no v�lido, no puede ser negativo, introduzca de nuevo: ");
			fila2 = teclado.nextInt();
			
		}
		
		colum2 = teclado.nextInt();
		
		//Se valida el dato
		while (colum2 < 0) {
			
			System.out.println("Dato no v�lido, no puede ser negativo, introduzca de nuevo: ");
			colum2 = teclado.nextInt();
			
		}
		
		//Se comprueba si se puede realizar la operacion
		if (colum1 == fila2) {
			
			//Se piden datos para la primera matriz
			
			matriz1 = new int[fila1][colum1];
			
			System.out.println("Va a introducir los valores de la primera matriz");
			
			for (int i = 0; i <= fila1 - 1; i++) {
				
				for (int y = 0; y <= colum1 - 1; y++) {
					
					System.out.println("Introduzca el valor que corresponde a la fila " + (i+1) + " columna " + (y+1) + ":");
					matriz1[i][y] = teclado.nextInt();
					
				}
				
			}
			
			//Se piden los datos de la segunda matriz
			
			matriz2 = new int[fila2][colum2];
			
			System.out.println("Va a introducir los valores de la segunda matriz");
			
			for (int i = 0; i <= fila2 - 1; i++) {
				
				for (int y = 0; y <= colum2 - 1; y++) {
					
					System.out.println("Introduzca el valor que corresponde a la fila " + (i+1) + " columna " + (y+1) + ":");
					matriz2[i][y] = teclado.nextInt();
					
				}
				
			}
			
			//Se calcula la matriz resultante que tendra de dimensiones fila1 y colum2
			
			matrizResul = new int [fila1][colum2];
			
			for (int i = 0; i <= fila1 - 1; i++) {
								
				for (int y = 0; y <= colum2 - 1; y++) {
					
					cuenta = 0; //Se inicializa la variable cada vez que se va a calcular un numero nuevo

					for (int x = 0; x <= colum1 - 1; x++) {
						
						aux = matriz1[i][x] * matriz2[x][y];
						cuenta = cuenta + aux;
						
					}
					
					matrizResul[i][y] = cuenta;
					
				}
				
			}
			
			//Se muestra la matriz resultante
			for (int i = 0; i <= fila1 - 1; i++) {
				
				for (int y = 0; y <= colum2 - 1; y++) {
										
					if ((y == colum2 - 1)) {
						
						System.out.print(matrizResul[i][y]);
						
					}
					
					else {
						
						System.out.print(matrizResul[i][y] + " -- ");
						
					}
										
				}
				
				System.out.println("");
				
			}
			
			
		}
		
		else {
			
			System.out.println("No se pueden multiplicar");
			
		}
		
		
		teclado.close();
		
	}

}
