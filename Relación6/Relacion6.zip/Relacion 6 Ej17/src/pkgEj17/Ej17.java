package pkgEj17;
import java.util.Scanner;
public class Ej17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		String texto; //Variable para almacenar el texto dado
		int clave = 0; //Variable para saber si es o no igual
		
		//Se pide el texto
		System.out.println("Introduzca el texto: ");
		texto = teclado.nextLine();
		
		//Se procesan los datos
		for (int i = 0; i <= texto.length() - 1; i++) {
			
			if (texto.substring(i, i + 1).equals(texto.substring(texto.length() - i - 1, texto.length() - i))) {
				
				clave++;
				
			}
			
		}
		
		
		//Se muestran los datos
		if (clave == texto.length()) {
			
			System.out.println("Es palindronomo");
			
		}
		
		else {
			
			System.out.println("No es palindronomo");
			
		}
		
		teclado.close();
		
		
	}

}
