package pkgEj15;
import java.util.Scanner;
public class Ej15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		String texto; //Variable para almacenar el texto a introducir por el user
		String consLista; //Variable para guardar todas las consonantes
		String vocLista; //Variable para guardar todas las vocales
		int vocales, consonantes; //Variables para almacenar el numero de cada una
		
		//Se pide el texto al usuario
		System.out.println("Introduzca el texto: ");
		texto = teclado.nextLine();
		
		//Se procesan los datos
		
		texto = texto.toLowerCase(); //Se pasa a minusculas
		
		//Se inicializan las variables
		vocales = 0;
		consonantes = 0;
		
		//Se le dan los datos a la variable que almacena las consonantes y vocales
		consLista = "bcdfghjklmn�pqrstvwxyz";
		vocLista = "aeiou";
		
		//Mediante un bucle comparamos letra a letra y si coincide se suma a la variable adecuada
		for (int i = 0; i <= texto.length() - 1; i++) {
			
			if (vocLista.indexOf(texto.substring(i, i + 1)) != -1) {
				
				vocales++;
				
			}
			
			else if (consLista.indexOf(texto.substring(i, i + 1)) != -1) {
				
				consonantes++;
				
			}
		}
		
		//Se muestran los datos
		System.out.println("El n�mero de vocales es: " + vocales);
		System.out.println("El n�mero de consonantes es: " + consonantes);
		
		teclado.close();
		
		
		
		
		
		
		
		
	}

}
