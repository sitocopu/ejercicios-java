package pkgEj1;
import java.util.Scanner;
public class Ej1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		 double notas[] = new double[15]; //Se almacenaran las notas pedidas
		 double media = 0; //Variable para almacenar la media
		 
		 //Se piden las notas
		 System.out.println("Introduzca las 15 notas (no pueden ser valores negativos y no pueden superar el 10): ");
		 for (int i = 0; i <= 14; i++) {
			  
			 notas[i] = teclado.nextDouble();
			  
			  //Se valida
			  while (notas[i] < 0 || notas[i] > 10) {
				  
				  System.out.println("Dato no v�lido, introduzca de nuevo: ");
				  notas[i] = teclado.nextDouble();
				  
			  }
			  
		 }
		 
		 //Se realiza un bucle para calcular la media
		 for (int i = 0; i <= 14; i++) {
			 
			 media = media + notas[i];
			 
		 }
		 
		 media = media/notas.length;
		 
		 //Se muestran los resultados
		 System.out.println("La media es: " + media);
		 
		 //Se calculan los que superan la media mediante un bucle y se muestra
		 System.out.println("----------------------------------");
		 System.out.println("Relaci�n de notas que superan la media: ");
		 
		 for (int i = 0; i <= 14; i++) {
			 
			 if (notas[i] > media) {
				 
				 System.out.println(notas[i]);
				 
			 }
			 
		 }
		
		
		
		teclado.close();
		
		
		
		
		
		
	}

}
