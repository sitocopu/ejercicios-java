package pkgEj5;
import java.util.Scanner;
public class Ej5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		int numPelis; //Variable para guardar el numero de peliculas a guardar
		int clave; //Variable para entrar en el switch
		int duracion; 
		int numLista = 0; //Variable para mostrar el numero de peliculas
		String paso; //Variable para poder guardar datos de cadena
		String genero;
		
		System.out.println("Introduzca el n�mero de peliculas que desea guardar (m�ximo 100): ");
		numPelis = teclado.nextInt();
		
		//Se valida el dato
		while (numPelis < 0 || numPelis > 100) {
			
			System.out.println("Dato incorrecto, introduzca de nuevo (tiene qque ser positivo): ");
			numPelis = teclado.nextInt();
			
		}
		
		paso = teclado.nextLine();

		String[] nombres= new String [numPelis];
		int[] duraciones = new int[numPelis];
		String[] generos = new String[numPelis];
		
		//Se piden los datos de cada pelicula
		for (int i = 0; i <= numPelis - 1; i++) {
			
			//***Se pide el nombre***
			System.out.println("Introduzca el nombre de la pelicula " + (i + 1) + ": ");
			nombres[i] = teclado.nextLine();
			
			//***Se pide el genero***
			System.out.println("Introduzca el g�nero (T/D/C): ");
			generos[i] = teclado.nextLine();
			
			//Se valida el dato
			while (!generos[i].equals("T") && !generos[i].equals("D") && !generos[i].equals("C")) {
				
				System.out.println("Dato no v�lido, introduzca de nuevo: ");
				generos[i] = teclado.nextLine();
				
			}
			
			//***Se pide la duracion***
			System.out.println("Introduzca la duraci�n de la pelicula: ");
			duraciones[i] = teclado.nextInt();
			
			//Se valida el dato
			while (duraciones[i] < 45 || duraciones[i] > 180) {
				
				System.out.println("Dato no v�lido, introduzca de nuevo: ");
				duraciones[i] = teclado.nextInt();
				
			}
			
			paso = teclado.nextLine();
		}
		
		//Se realiza un switch para pedir al usuario una opcion
		
		System.out.println("1-buscar pel�culas por g�nero, 2- buscar pel�culas por duraci�n, 3-salir");
		clave = teclado.nextInt();
		
		switch (clave) {
		
		case 1:
			
			System.out.println("Introduzca el genero: ");
			paso = teclado.nextLine();
			genero = teclado.nextLine();
			
			//Se valida
			while (genero != "T" || genero != "D" || genero != "C") {
				
				System.out.println("Dato no v�lido, introduzca de nuevo: ");
				genero = teclado.nextLine();
				
			}
			
			//Se muestran los datos
			for (int i = 0; i <= numPelis - 1; i++) {
				
				if (generos[i] == genero) {
					
					System.out.println(nombres[i]);
					System.out.println(duraciones[i]);
					System.out.println("------------------");
					numLista = numLista++;
				}
				
			}
			
			//Se muestra el numero de peliculas
			System.out.println("Hay " + numLista + " peliculas" );
			
			break;
			
		case 2:
			
			System.out.println("Introduzca la duraci�n :");
			duracion = teclado.nextInt();
			
			//Se valida el dato
			while (duracion < 45 || duracion > 180) {
				
				System.out.println("Dato no v�lido, introduzca de nuevo: ");
				duracion = teclado.nextInt();
				
			}
			
			//Se muestran los datos
			for (int i = 0; i <= numPelis - 1; i++) {
				
				if (duraciones[i] <= duracion ) {
					
					System.out.println(nombres[i]);
					System.out.println(duraciones[i]);
					System.out.println("------------------");
					numLista = numLista++;
					
				}
				
			}
			
			//Se muestra el numero de peliculas
			System.out.println("Hay " + numLista + " peliculas" );
			
			break;
			
		case 3:
			
			break;
			
		}
		
		
		
		
		
		
		
		
	}

}
