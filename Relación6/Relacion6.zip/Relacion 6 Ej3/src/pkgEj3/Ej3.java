package pkgEj3;
import java.util.Scanner;
public class Ej3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in); //Lector
		
		int num; //Numero de asterisco que va a tener
		
		System.out.println("Introduzca el numero de asteriscos que quiere que tenga(minimo 3): ");
		num = teclado.nextInt();
		
		//Se valida
		while (num < 3) {
			
			System.out.println("Dato no v�lido, introduzca de nuevo(tiene que ser positivo): ");
			num = teclado.nextInt();
			
		}
		
		String[] caracteres = new String[2]; //Cadena para guardar los tipos de caracteres para formar el cuadrado
		
		caracteres[0] = "*";
		caracteres[1] = " ";
		
		
		//Se muestra el cuadrado
		for (int i = 1; i <= num; i++) { //Va mostrando linea a linea
			if (i == 1 || i == num) { //La primera linea es toda de asteriscos
				
				System.out.println("");
				for (int y = 1; y <= num; y++) {
					
					System.out.print(caracteres[0]);
					
				}
			
			}
			
			else { //Sino solo las esquinas tienen asteriscos
				
				System.out.println("");
				
				for (int x = 1; x <= num; x++) {
					
					if (x == 1 || x == num) {
						
						System.out.print(caracteres[0]);
						
					}
					
					else {
						
						System.out.print(caracteres[1]);
						
					}
					
				}
			
			}
			
		}
		
		
		
		
		
		
		
	}

}
