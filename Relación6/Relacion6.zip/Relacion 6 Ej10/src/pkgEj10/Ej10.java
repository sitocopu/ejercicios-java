package pkgEj10;
import java.util.Scanner;
public class Ej10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		int cantidad; //Variable para almacenar la cantidad de numeros que quiere introducir
		int aux; //Variable para procesar datos
		int num[]; //Cadena para almacenar los numeros
		
		//Se pide la cantidad al usuario
		System.out.println("Introduzca la cantidad de numeros que quiere introducir: ");
		cantidad = teclado.nextInt();
		
		//Se valida
		while (cantidad < 0) {
			
			System.out.println("Dato no v�lido, introduzca de nuevo: ");
			cantidad = teclado.nextInt();
			
		}
		
		//Se crea la variable
		num = new int[cantidad];
		
		//Se introducen los datos
		
		System.out.println("Introduzca los n�meros: ");
		for (int i = 0; i <= cantidad - 1; i++) {
			
			System.out.println("N�mero " + (i + 1) + ": ");
			num[i] = teclado.nextInt();
			
		}
		
		//Se procesan los datos
		for (int i = 0; i <= cantidad - 1; i++) {
			
			for (int y = 0; y <= cantidad - 1; y++) {
				
				if (num[i] < num[y]) {
					
					aux = num[i];
					num[i] = num[y];
					num[y] = aux;
					
				}
				
			}
			
		}
		
		//Se muestran los datos
		for (int i = 0; i <= cantidad - 1; i++) {
			
			if (!(i == cantidad - 1)) {
				
				System.out.print(num[i] + " -- ");
			
			}
			
			else {
				
				System.out.print(num[i]);
				
			}
			
		}
		
		teclado.close();
		
		
		
		
	}

}
