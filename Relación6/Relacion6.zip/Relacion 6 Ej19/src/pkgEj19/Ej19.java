package pkgEj19;
import java.util.Scanner;
public class Ej19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		String texto; //Variable para almacenar e texto dado
		String palabra; //Variable para almacenar la palabra a buscar
		int coincidencias = 0; //Variable para saber si la palabra coincide
		int numPalabras = 0; //Variable para almacenar la cantidad de veces que se repite la palabra a buscar
		
		//Se pide el texto
		System.out.println("Introduzca el texto: ");
		texto = teclado.nextLine();
		
		//Se pide la palabra a buscar
		System.out.println("Introduzca la palabra: ");
		palabra = teclado.nextLine();
				
		//Se procesan los datos
		for (int i = 0; i <= texto.length() - 1; i++) { //Mediante un bucle recorremos todo el texto
			
			 if (palabra.indexOf(texto.substring(i, i + 1)) != -1) { //Si la letra que recorremos coincide sumamos uno a coincidencias
				 
				 coincidencias++;
				 
				 if (coincidencias == palabra.length()) { //Si coincidencias llega al numero de letras de la palabra se ha encontrado una
					 
					 numPalabras++;
					 coincidencias = 0;
					 
				 }
				 
			 }
			
			 else { //Sino coincide se reinicia el contador
				 
				 coincidencias = 0;
				 
			 }
		}
		
		//Se muestran los datos
		System.out.println("La palabra se repite " + numPalabras + " veces.");
		
		
		teclado.close();
		
		
		
	}

}
