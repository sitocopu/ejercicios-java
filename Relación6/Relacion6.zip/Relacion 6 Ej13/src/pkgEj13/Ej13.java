package pkgEj13;
import java.util.Scanner;
public class Ej13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		int cantidadAlum; //Variable para almacenar la cantidad de alumnos a introducir
		String nombres[]; //Cadena para guardar los nombres
		String paso; //Variable para guardar el intro
		String auxNom; //variable para ordenar nombres
		int auxNum; //Variable para ordenar notas
		int notas[]; //Cadena para guardar las notas de los alumnos
		
		System.out.println("Introduzca la cantidad del alumnos que va a introducir: ");
		cantidadAlum = teclado.nextInt();
		
		//Se valida
		while (cantidadAlum <0) {
			
			System.out.println("Dato no valido, introduzca de nuevo: ");
			cantidadAlum = teclado.nextInt();
			
		}
		
		nombres = new String[cantidadAlum];
		notas = new int[cantidadAlum];
		paso = teclado.nextLine();
		
		//Se introducen los alumnos y sus respectivas notas
		for (int i = 0; i<= cantidadAlum - 1; i++) {
			
			System.out.println("Introduzca el nombre del alumno " + (i+1) + ": ");
			nombres[i] = teclado.nextLine();
			
			System.out.println("Introduzca su nota: ");
			notas[i] = teclado.nextInt();
			
			//Se valida
			while (notas[i] < 0 || notas[i] > 10) {
				
				System.out.println("Dato no valido, introduzca de nuevo: ");
				notas[i] = teclado.nextInt();
				
			} 
			
			paso = teclado.nextLine();
		}
		
		//Se ordenan los datos
		for (int i = 0; i <= cantidadAlum - 1; i++) {
			
			for (int y = 0; y <= cantidadAlum - 1; y++) {
				
				if (nombres[i].compareTo(nombres[y]) < 0) {
					
					//Se ordena el nombre
					auxNom = nombres[i];
					nombres[i] = nombres[y];
					nombres[y] = auxNom;
					
					//Se ordena su nota
					auxNum = notas[i];
					notas[i] = notas[y];
					notas[y] = auxNum;
					
				}
				
			}
			
		}
		
		//Se muestran los datos
		for (int i = 0; i <= cantidadAlum - 1; i++) {
			
			System.out.println(nombres[i] + " --> " + notas[i]);
			
		}
		
		teclado.close();
		
		
	}

}
