package pkgEj6;
import java.util.Scanner;
public class Ej6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		long num; //Variable para almacenar el numero dado por el usuario
		long aux; //Variable para almacenar numeros intermedios
		int apollo = 1; //Variable para calcular los datos
		long inver = 0; //Variable para calcular los datos
		long cifras[]; //Cadena para almacenar las cifras. 
		
		System.out.println("Introduzca el n�mero: ");
		num = teclado.nextInt();
		
		aux = num;
		
		if (num > 0 && num < 9 ) {
			System.out.println(num);
		}
		
		else if (num > 10 && num < 99) {
			
			//Se declara el numero de casillas de la cadena
			cifras = new long[2];
			
			//Se calculan los datos
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = 0; i <= cifras.length-1; i++) {
				cifras[i] = aux/apollo;
				aux = aux - cifras[i]*apollo;
				
				apollo = apollo/10;
				
			}
			
			//Se muestran los datos
			
			apollo = 1;
			
			//Se le da la vuelta al numero
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = cifras.length - 1; i >= 0; i--) {
				inver = inver + cifras[i]*apollo;
				
				apollo = apollo/10;
			}
		}
		
		else if (num > 100 && num < 999) {
			
			//Se declara el numero de casillas de la cadena
			cifras = new long[3];
			
			//Se calculan los datos
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = 0; i <= cifras.length-1; i++) {
				cifras[i] = aux/apollo;
				aux = aux - cifras[i]*apollo;
				
				apollo = apollo/10;
				
			}
			
			//Se muestran los datos
			
			apollo = 1;
			
			//Se le da la vuelta al numero
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = cifras.length - 1; i >= 0; i--) {
				inver = inver + cifras[i]*apollo;
				
				apollo = apollo/10;
			}
			
		}
		
		else if (num > 1000 && num < 9999) {
			
			//Se declara el numero de casillas de la cadena
			cifras = new long[4];
			
			//Se calculan los datos
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = 0; i <= cifras.length-1; i++) {
				cifras[i] = aux/apollo;
				aux = aux - cifras[i]*apollo;
				
				apollo = apollo/10;
				
			}
			
			//Se muestran los datos
			
			apollo = 1;
			
			//Se le da la vuelta al numero
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = cifras.length - 1; i >= 0; i--) {
				inver = inver + cifras[i]*apollo;
				
				apollo = apollo/10;
			}
			
		}
		
		else if (num > 10000 && num < 99999) {
			
			//Se declara el numero de casillas de la cadena
			cifras = new long[5];
			
			//Se calculan los datos
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = 0; i <= cifras.length-1; i++) {
				cifras[i] = aux/apollo;
				aux = aux - cifras[i]*apollo;
				
				apollo = apollo/10;
				
			}
			
			//Se muestran los datos
			
			apollo = 1;
			
			//Se le da la vuelta al numero
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = cifras.length - 1; i >= 0; i--) {
				inver = inver + cifras[i]*apollo;
				
				apollo = apollo/10;
			}
			
		}
		
		else if (num > 100000 && num < 999999) {
			
			//Se declara el numero de casillas de la cadena
			cifras = new long[6];
			
			//Se calculan los datos
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = 0; i <= cifras.length-1; i++) {
				cifras[i] = aux/apollo;
				aux = aux - cifras[i]*apollo;
				
				apollo = apollo/10;
				
			}
			
			//Se muestran los datos
			
			apollo = 1;
			
			//Se le da la vuelta al numero
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = cifras.length - 1; i >= 0; i--) {
				inver = inver + cifras[i]*apollo;
				
				apollo = apollo/10;
			}
			
		}
		
		else if (num > 1000000 && num < 9999999) {
			
			//Se declara el numero de casillas de la cadena
			cifras = new long[7];
			
			//Se calculan los datos
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = 0; i <= cifras.length-1; i++) {
				cifras[i] = aux/apollo;
				aux = aux - cifras[i]*apollo;
				
				apollo = apollo/10;
				
			}
			
			//Se muestran los datos
			
			apollo = 1;
			
			//Se le da la vuelta al numero
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = cifras.length - 1; i >= 0; i--) {
				inver = inver + cifras[i]*apollo;
				
				apollo = apollo/10;
			}
			
		}
		
		else if (num > 10000000 && num < 99999999) {
			
			//Se declara el numero de casillas de la cadena
			cifras = new long[8];
			
			//Se calculan los datos
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = 0; i <= cifras.length-1; i++) {
				cifras[i] = aux/apollo;
				aux = aux - cifras[i]*apollo;
				
				apollo = apollo/10;
				
			}
			
			//Se muestran los datos
			
			apollo = 1;
			
			//Se le da la vuelta al numero
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = cifras.length - 1; i >= 0; i--) {
				inver = inver + cifras[i]*apollo;
				
				apollo = apollo/10;
			}
			
		}
		
		else if (num > 100000000 && num < 999999999) {
			
			//Se declara el numero de casillas de la cadena
			cifras = new long[9];
			
			//Se calculan los datos
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = 0; i <= cifras.length-1; i++) {
				cifras[i] = aux/apollo;
				aux = aux - cifras[i]*apollo;
				
				apollo = apollo/10;
				
			}
			
			//Se muestran los datos
			
			apollo = 1;
			
			//Se le da la vuelta al numero
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = cifras.length - 1; i >= 0; i--) {
				inver = inver + cifras[i]*apollo;
				
				apollo = apollo/10;
			}
			
		}
		
		/*else if (num > 1000000000 && num < 9999999999) {
			
			//Se declara el numero de casillas de la cadena
			cifras = new long[10];
			
			//Se calculan los datos
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = 0; i <= cifras.length-1; i++) {
				cifras[i] = aux/apollo;
				aux = aux - cifras[i]*apollo;
				
				apollo = apollo/10;
				
			}
			
			//Se muestran los datos
			
			apollo = 1;
			
			//Se le da la vuelta al numero
			for (int i = 1; i <=cifras.length-1; i++) {
				apollo = apollo*10;
			}
			
			for (int i = cifras.length - 1; i >= 0; i--) {
				inver = inver + cifras[i]*apollo;
				
				apollo = apollo/10;
			}
			
		}*/ //No da el rango de numeros
		
		//Se muestra la solucion
		System.out.println(inver);
		
		teclado.close();
		
		
	}

}
