package pkgEj8;
import java.util.Scanner;
public class EJ8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner teclado = new Scanner(System.in);
		
		int num; //Variable para almacenar el numero pedido
		int aux; //Variable para trabajar el numero introducido
		int binarios[]; //cadena para guardar los digitos binarios
		int cont; //Variable para guardar la cantida de veces que se divide el numero
		
		//Se pide el numero
		System.out.println("Introduzca el n�mero: ");
		num = teclado.nextInt();
		
		//Se valida el dato
		while (num < 0) {
			
			System.out.println("Dato no v�lido, ha de ser positivo, introduzca de nuevo:");
			num = teclado.nextInt();
			
		}
		
		//Se calcula las veces que se divide
		
		//Se inicializan variables
		aux = num;
		cont = 0;
		
		//Se cuenta
		do {
			
			aux = aux/2;
			cont++;
			
		} while (!(aux == 1));
		
		//Se almacenan los digitos binarios
		binarios = new int[cont]; //Se declara la cantidad de celdas de la cadena
		
		aux = num; //Reutilizamos la variable
		
		//Almacenamos los datos en la cadena
		for (int i = 0; i <= binarios.length - 1; i++) {
			
			binarios[i] = aux%2;
			aux = aux/2;
			
		}
		
		//Mostramos el dato teniendo en cuenta que el primer valor siempre es 1
		System.out.print("1");
		
		for (int i = binarios.length - 1; i >= 0; i--) {
			
			System.out.print(binarios[i]);
			
		}
		
		teclado.close();
		
	}

}
